#!/usr/bin/python3
import hashlib
from flask import request, session, redirect, url_for,Response
from flask_restful import Resource,reqparse
from .db import db
from ..errors import NOT_ACCEPTABLE,INVALID_DATA,NOT_FOUND, OK
from .crud import CRUDBase

class static_Class(Resource):
    def get(self):
        #return render_template('web.html')
        temp_entry = open('web.html','r').read()
        resp = Response(temp_entry,mimetype='text/html')
        return resp
