#!/usr/bin/python3
import hashlib,base64,urllib.parse
from bson.objectid import ObjectId
from flask import request, session, redirect, url_for
from flask_restful import Resource,reqparse
from ..db import db
from ...errors import NOT_ACCEPTABLE,INVALID_DATA,NOT_FOUND, OK
from ..crud import CRUDBase
from ...decorators import IpCheck,LoginCheck
import http.client
import json
class CheckClass(Resource):
    method_decorators = dict(post=[LoginCheck],get=[LoginCheck])
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('name',type=str,required=True,help='invalid name')
        parser.add_argument('method',type=str,required=True,help='method must be string type')
        parser.add_argument('host',type=str,required=True,help='invalid host')
        parser.add_argument('port',type=int,required=True,help='port must be int type')
        parser.add_argument('url',type=str,required=True,help='invalid url')
        parser.add_argument('timeout',type=int,required=True,help='timeout must be int of sec')
        args = parser.parse_args()
        url = urllib.parse.unquote(f'{args.url}')
        if url.strip().lower().find('upload') != -1:
            raise INVALID_DATA
        check_dict = dict(name=f'{args.name}',method=f'{args.method}',host=args.host,port=args.port,timeout=args.timeout,url=args.url,user=ObjectId(session['id']))
        check_db = CRUDBase('check')
        check_db.create(spec=check_dict)
        return {'success':True,'message':'check command has been successfully created'}
        #raise INVALID_DATA

    def get(self):
        check_db = CRUDBase('check')
        check_dict = dict(user=ObjectId(session['id']))
        checkResponse = check_db.read(spec=check_dict)
        return_dict = {'success':True,'message':[]}
        for check in checkResponse:
            check['id'] = str(check.pop('_id'))
            check.pop('user')
            return_dict['message'].append(check)
        return return_dict

class CheckListClass(Resource):
    def get(self,id):
        check_db = CRUDBase('check')
        try:
            check_dict = dict(_id=ObjectId(id))
        except:
            raise INVALID_DATA
        Response = check_db.read(spec=check_dict,find_one=True)
        if Response:
            host = Response['host']
            port = Response['port']
            url = Response['url']
            method = Response['method']
            timeout = Response['timeout']
            #TODO: session check & valid user res
            conn = http.client.HTTPConnection(host, port,timeout=5)
            req = conn.request(method=method,url=url)
            return_dict = dict(success=True,message=[])
            try:
                resp = conn.getresponse().read()
                encoded_resp = base64.b64encode(resp)
                return_dict['message'].append(encoded_resp.decode('utf-8'))
                return return_dict
            except:
                raise INVALID_DATA
            return True
        raise NOT_ACCEPTABLE
