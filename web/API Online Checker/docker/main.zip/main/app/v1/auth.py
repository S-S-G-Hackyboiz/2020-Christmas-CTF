#!/usr/bin/python3
import hashlib
from bson.objectid import ObjectId
from flask import request, session, redirect, url_for
from flask_restful import Resource,reqparse
from .db import db
from ..errors import NOT_ACCEPTABLE,INVALID_DATA,NOT_FOUND
from .crud import CRUDBase
class AuthClass(Resource):
    def post(self):
        '''
            CREATE Session (Login)
        '''
        userdb = CRUDBase('user')
        parser = reqparse.RequestParser()
        parser.add_argument('userid',type=str,required=True,help='invalid userid')
        parser.add_argument('userpw',type=str,required=True,help='invalid userpw')
        args = parser.parse_args()
        uid = f'{args.userid}'
        upw = f'{hashlib.sha256(args.userpw.encode()).hexdigest()}'
        login_dict = dict(userid=uid,userpw=upw)
        userResponse = userdb.read(spec=login_dict,find_one=True)
        if userResponse:
            session['userid'] = userResponse['userid']
            session['id'] = str(userResponse['_id'])
            return {'success':True,'message':'login ok'}
        raise INVALID_DATA
    
    def get(self):
        '''
            READ session info
        '''
        if not session:
            raise NOT_FOUND
        userdb = CRUDBase('user')
        try:
            user_dict = dict(_id=ObjectId(session['id']))
        except:
            raise INVALID_DATA
        userResponse = userdb.read(spec=user_dict,find_one=True)
        return_dict = dict(success=True,message=[])
        if userResponse:
            userResponse.pop('userpw')
            userResponse['id'] = str(userResponse.pop('_id'))
            return_dict['message'].append(userResponse)
        return return_dict
