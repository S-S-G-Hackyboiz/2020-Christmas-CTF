#!/usr/bin/python3
import hashlib
from flask import request, session, redirect, url_for
from flask_restful import Resource,reqparse
from .db import db
from ..errors import NOT_ACCEPTABLE,INVALID_DATA,NOT_FOUND, OK
from .crud import CRUDBase
class UserClass(Resource):
    def post(self):
        '''
            CREATE User
        '''
        parser = reqparse.RequestParser()
        parser.add_argument('userid',type=str,required=True,help='invalid userid')
        parser.add_argument('userpw',type=str,required=True,help='invalid userpw')
        args = parser.parse_args()
        userdb = CRUDBase('user')
        user_dict = dict(userid=f'{args.userid}')
        userResponse = userdb.duplicate_check(spec=user_dict)
        if not userResponse:
            user_dict.update(dict(userpw=f'{hashlib.sha256(args.userpw.encode()).hexdigest()}'))
            userdb.create(spec=user_dict)
            return {'success':True,'message':'your account has been successfully created'}
        raise INVALID_DATA
