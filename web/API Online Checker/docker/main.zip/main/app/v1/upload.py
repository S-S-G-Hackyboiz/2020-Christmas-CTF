#!/usr/bin/python3
import os
import hashlib,fleep,uuid,json
from flask import request, session, redirect, url_for, current_app, send_from_directory
from werkzeug import datastructures
from werkzeug.utils import secure_filename
from flask_restful import Resource,reqparse
from bson.objectid import ObjectId
from .db import db
from ..errors import NOT_ACCEPTABLE,INVALID_DATA,NOT_FOUND,NOT_AUTHORIZED
from .crud import CRUDBase
from ..utils import file_util
from ..decorators import IpCheck,LoginCheck

class UploadClass(Resource):
    class_decorators = dict(post=[LoginCheck],get=[LoginCheck])
    def post(self):
        '''
        Create Upload File Object
        '''
        #TODO: file encryption, file duplicate check, db insert
        root_path = current_app.config['UPLOAD_DIR']

        parser = reqparse.RequestParser()
        parser.add_argument('file',type=datastructures.FileStorage,location='files', required=True)
        parser.add_argument('api',type=str,required=False,help='api must be ObjectId of check')
        args = parser.parse_args()
        if args.file and args.file.filename:
            filename = secure_filename(f'{args.file.filename}')
            rand_filename = str(uuid.uuid4())
            extension = filename.rsplit('.', 1)[1]
            if not file_util.allowed_file(filename):
                raise INVALID_DATA
            save_file_path = os.path.join(root_path,filename)
            rand_file_path = os.path.join(root_path,rand_filename)
            args.file.save(save_file_path)
            with open(save_file_path, "rb") as file:
                info = fleep.get(file.read(128))
                mime_type = info.mime
            if not info.extension_matches(extension):
                raise INVALID_DATA
            if mime_type and file_util.allowed_mime(mime_type):
                try:
                    if not file_util.encrypt(save_file_path,rand_file_path):
                        raise INVALID_DATA
                    userdb = CRUDBase('user')
                    upload_db = CRUDBase('upload')
                    user_dict = dict(_id=ObjectId(session['id']))
                    userResponse = userdb.read(spec=user_dict,find_one=True)
                    if userResponse:
                        upload_dict = dict(user=ObjectId(session['id']), origin=filename,name=rand_filename)
                        print(upload_dict)
                        upload_db = CRUDBase('upload')
                        upload_db.create(spec=upload_dict)
                #except:
                #    raise INVALID_DATA
                except Exception as e:
                    print(e)
                    raise INVALID_DATA
                return {'success':True,'message':'정상적으로 업로드 되었습니다.'}
            else:
                os.remove(save_file_path)
                raise INVALID_DATA
    def get(self):
        '''
        READ Upload File Object
        '''
        parser = reqparse.RequestParser()
        parser.add_argument('name',type=str,required=False)
        args = parser.parse_args()
        upload_db = CRUDBase('upload')
        return_dict = dict(status=True,message=[])
        if args.name:
            try:
                upload_dict = dict(name=json.loads(args.name.replace("'","\"")))
            except Exception as e:
                upload_dict = dict(name=args.name)
            try:
                uploadResponse = upload_db.read(spec=upload_dict,find_one=True)
            except:
                raise INVALID_DATA
            if uploadResponse:
                uploadResponse['id'] = str(uploadResponse.pop('_id'))
                uploadResponse.pop('user')
                return_dict['message'].append(uploadResponse)
        else:
            upload_dict = dict(user=ObjectId(session['id']))
            uploadResponse = upload_db.read(spec=upload_dict)
            if uploadResponse:
                for upload in uploadResponse:
                    upload['id'] = str(upload.pop('_id'))
                    upload.pop('user')
                    return_dict['message'].append(upload)
        return return_dict

class UploadListClass(Resource):
    class_decorators = dict(get=[IpCheck])
    def get(self,id):
        if request.remote_addr != '127.0.0.1':
            raise NOT_AUTHORIZED
        upload_db = CRUDBase('upload')
        root_path = current_app.config['UPLOAD_DIR']
        try:
            upload_dict = dict(_id=ObjectId(id))
            uploadResponse = upload_db.read(spec=upload_dict,find_one=True)
            if uploadResponse:
                #decrypt func
                file_path = os.path.join(root_path,uploadResponse['name'])
                decrypt_path = os.path.join('/tmp/',uploadResponse['name'])
                file_util.decrypt(file_path,decrypt_path)
                return send_from_directory('/tmp/',uploadResponse['name'],attachment_filename=uploadResponse['origin'],as_attachment=True)
            #TODO: FIX file delete issue
            else:
                return NOT_FOUND
        #except Exception as e:
            #print(e)
        except:
            raise INVALID_DATA
