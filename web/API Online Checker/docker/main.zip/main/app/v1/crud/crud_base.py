#!/usr/bin/python3
from ..db import db
from .base import CRUDBase
import json    
from bson import json_util

#TODO : add read using _id
#TODO : add ordered func when insert or insert_many
#TODO : add serial / deserial option in func 
class CRUDBase(CRUDBase):
    def __init__(self, table):
        self.table = table

    def SerialJson(self,response):
        return json.dumps(response, default=json_util.default)
    def DeserialJson(self,response):
        return json.loads(response, object_hook=json_util.object_hook)
    def duplicate_check(self,spec):
        response = db[self.table].find_one(spec)
        if response:
            return True
        else:
            return False
    def create(self,spec):
        if isinstance(spec,list):
            response = db[self.table].insert_many(spec)
        else:
            response = db[self.table].insert_one(spec)
        return response


    def read(self,spec=None,skip=0,limit=0,find_one=False):
        if not spec:
            spec = {}
        if isinstance(spec,list):
            response = db[self.table].aggregate(spec)
        else:
            if find_one:
                response = db[self.table].find_one(spec)
            else:
                response = db[self.table].find(spec,skip=skip,limit=limit)
        return response

    def count(self,spec=None):
        if not spec:
            spec = {}
        if isinstance(spec,list):
            response = db[self.table].aggregate(spec)
        else:
            response = db[self.table].count(spec)
        return response

    def update(self,spec=None):
        #spec will be array with src and val
        if not spec:
            return False
        if not isinstance(spec,list):
            return False
        src = spec[0]
        val = spec[1]
        val = {'$set':val}
        response = db[self.table].update_one(src,val)
        return response

    def delete(db,spec=None,operator=None):
        raise NotImplemented()
