#!/usr/bin/python3
class CRUDBase():
    def __init__(self):
        return
    def get(db,spec,operator=None):
        raise NotImplemented()
    def create(db,spec,operator=None):
        raise NotImplemented()
    def read(db,spec=None,operator=None):
        raise NotImplemented()
    def update(db,spec,operator=None):
        raise NotImplemented()
    def delete(db,spec=None,operator=None):
        raise NotImplemented()
