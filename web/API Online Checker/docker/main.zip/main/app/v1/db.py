from pymongo import MongoClient

'''
    MongoDB
'''
db = MongoClient('mongodb://localhost:27017/ctfweb').ctfweb
