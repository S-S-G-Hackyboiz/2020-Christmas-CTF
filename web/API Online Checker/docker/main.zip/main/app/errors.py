from werkzeug.exceptions import HTTPException

class NOT_ACCEPTABLE(HTTPException):
    pass
class INVALID_DATA(HTTPException):
    pass
class NOT_FOUND(HTTPException):
    pass
class NOT_AUTHORIZED(HTTPException):
    pass
#TODO: custom error code. 
errors = {
    'NOT_FOUND': {
        'message' : "Resource Not Found.",
        'status': 404,
    },
    'NOT_ACCEPTABLE': {
        'message': "Method Not Implemented.",
        'status': 406,
    },
    'INVALID_DATA':{
        'message': "Invalid Data Type.",
        'status': 412,
    },
    'NOT_AUTHORIZED': {
        'message': "Not Authorized",
        'status': 401,
    },
}

OK = {
        'status':True,
        'message':[]
    }
