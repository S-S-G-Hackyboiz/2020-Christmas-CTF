from functools import wraps
from flask import session, g, request, redirect, url_for
from ..errors import NOT_AUTHORIZED

def LoginCheck(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get('userid'):
            return f(*args, **kwargs)
        else:
            raise NOT_AUTHORIZED
    return decorated_function

def IpCheck(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if request.remote_addr == '127.0.0.1':
            return f(*args, **kwargs)
        else:
            raise NOT_AUTHORIZED
    return decorated_function

