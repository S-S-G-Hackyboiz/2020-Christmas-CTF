import os
from flask import Flask
from flask_restful import Api
from .errors import errors
from config import Config
def create_app():
    app = Flask(__name__,instance_relative_config=True)
    app.secret_key = 'kitribob!@#' or os.urandom(24)
    app.config.from_object(Config())
    api = Api(app,errors=errors)
    from .v1 import AuthClass
    from .v1 import UserClass
    from .v1 import CheckClass, CheckListClass
    from .v1 import UploadClass, UploadListClass
    from .v1 import static_Class # for temp :(
    api.add_resource(static_Class,'/')
    api.add_resource(AuthClass,'/auth')
    api.add_resource(UserClass,'/user')
    api.add_resource(CheckClass,'/api/check')
    api.add_resource(CheckListClass,'/api/check/<string:id>')
    api.add_resource(UploadClass,'/upload')
    api.add_resource(UploadListClass,'/upload/<string:id>')
    return app
