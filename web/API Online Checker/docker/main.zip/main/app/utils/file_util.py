from flask import current_app
import pyAesCrypt
import os
ALLOWED_FILE_TYPE_MAPPING = {
        'pdf': 'application/pdf',
        'png': 'image/png',
        'jpg': 'image/jpeg',
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'zip': 'application/zip'
    }

ALLOWED_EXTENSIONS = set(ALLOWED_FILE_TYPE_MAPPING.keys())
ALLOWED_MIME_TYPES = set(ALLOWED_FILE_TYPE_MAPPING.values())

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS
def allowed_mime(mimetype):
    return [mime for mime in mimetype if mime in ALLOWED_MIME_TYPES]

def encrypt(fpath,rpath,bufferSize=64 * 1024):
    key = current_app.config['ENC_KEY']
    #TODO: change iv to session's id with pad or split
    output_path = fpath + '.enc'
    try:
        with open(fpath, "rb") as fIn:
            with open(output_path, "wb") as fOut:
                pyAesCrypt.encryptStream(fIn, fOut, key, bufferSize)
                os.remove(fpath)
                os.rename(output_path,rpath)
        return True
    except:
        return False
def decrypt(fpath,rpath,bufferSize=64 * 1024):
    key = current_app.config['ENC_KEY']
    try:
        encFileSize = os.stat(fpath).st_size
        with open(fpath,"rb") as fIn:
            with open(rpath,"wb") as fOut:
                pyAesCrypt.decryptStream(fIn, fOut, key, bufferSize, encFileSize)
        return True
    except:
        return False
