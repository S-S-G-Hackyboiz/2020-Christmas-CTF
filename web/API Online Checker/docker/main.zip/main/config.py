import os
class Config(object):
    SECRET_KEY = b"Ww0VONMUhUnw7Fg7nP-MVkCD{{Ar0z4x'efm=6PD1-^gYGhKurh/?1}3@%98V"
    UPLOAD_DIR = os.path.abspath('app/upload')
    ENC_KEY = '*sO^jtG,4=dOW:j('
    enc_iv = "\\\xf4\xfed\x14'\x16\x7f\x0b\x13\x04\xa0rY\xb6Y"
class ProductionConfig(Config):
    pass

