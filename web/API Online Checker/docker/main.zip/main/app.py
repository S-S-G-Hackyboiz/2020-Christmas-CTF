from app import create_app

app = create_app()
app.run(host='0.0.0.0', port=80, debug=False, threaded=True,use_reloader=True)
